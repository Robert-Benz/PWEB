var jogador = prompt("Escolha Pedra, Papel ou Tesoura!").toUpperCase();
var computador = Math.random(0,1);
var decod;
var resultado;

if (computador < 0.34){
    decod = "PEDRA";
}
else if(computador < 0.67){
    decod = "PAPEL";
}
else if(computador < 1){
    decod = "TESOURA";
}

if (jogador == "PEDRA"){
    if(decod == "PEDRA"){
        resultado = "Empate!"
    }
    else if(decod == "PAPEL"){
        resultado = "Derrota!"
    }
    else if(decod == "TESOURA"){
        resultado = "Vitória!"
    }
}
else if (jogador == "PAPEL"){
    if(decod=="PEDRA"){
        resultado = "Vitória!"
    }
    else if(decod=="PAPEL"){
        resultado = "Empate!"
    }
    else if(decod=="TESOURA"){
        resultado = "Derrota!"
    }
}
else if (jogador == "TESOURA"){
    if(decod=="PEDRA"){
        resultado = "Derrota!"
    }
    else if(decod=="PAPEL"){
        resultado = "Vitória!"
    }
    else if(decod=="TESOURA"){
        resultado = "Empate!"
    }
}

alert(resultado + "\n" + "Sua mão: " + jogador + "\n" + "Mão do Computador: " + decod)