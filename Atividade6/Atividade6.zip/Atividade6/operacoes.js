//Variáveis Operacoes.html

    num1 = parseInt(prompt("Insira o Número 1"))
    num2 = parseInt(prompt("Insira o Número 2"))

    function operacoes(n1,n2){

        let soma = n1+n2;
        let sub = n1-n2;
        let prod = n1*n2;
        let div = n1/n2;
        let resto = n1%n2;
        
        alert("Soma dos números: " + soma + 
            "\nSubtração dos números: " + sub +
            "\nProduto dos números: " + prod + 
            "\nDivisão dos números: " + div +
            "\nResto da divisão dos números: " + resto
        );
    }
    operacoes(num1,num2);