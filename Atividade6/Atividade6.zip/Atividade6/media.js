//Variáveis Media.html

    var nome = prompt("Digite o nome do Aluno");

    var n1 = parseFloat(prompt("Digite a primeira nota"));
    var n2 = parseFloat(prompt("Digite a primeira nota"));
    var n3 = parseFloat(prompt("Digite a primeira nota"));
    var n4 = parseFloat(prompt("Digite a primeira nota"));

    var calculaMedia = function(n1,n2,n3,n4){
        let calcMedia;
        calcMedia = (n1 + n2 + n3 + n4) / 4
        return calcMedia;
    }

    var media = calculaMedia(n1,n2,n3,n4);

    alert("Media de Notas do Aluno " + nome + ": " + media);